package com.reinhrdt.logistik

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
