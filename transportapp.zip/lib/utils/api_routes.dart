class ApiRoutes {
  static const String baseUrl = 'http://vebrin.xyz/transportapp/api';

  // Authentication APIs
  static const String login = '$baseUrl/login-new';
  static const String tripApi = '$baseUrl/trips';
}
